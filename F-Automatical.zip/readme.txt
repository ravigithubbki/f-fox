F-Automatical v8

1) Been Fixed all bugs in previous versions.
2) Developed all options to operate more efficiently.
3) Added a feature to withdraw WHMCS and extract all roots/RDPs from hosting [6].
4) Added a new feature to login WordPress and upload Shell through Chrome (Automatically) [30].
5) Been Developed [INFO] be of higher quality and efficiency [3].